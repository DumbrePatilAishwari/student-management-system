# Online-Student-Management-System
This is Online Student Information Management System project developed using ASP.NET and SQL server as backend. This is web application  student information System which provides information of students and parents.

For more details about this project:
https://www.studentprojects.live/asp-net-projects/online-student-information-management-system/
